#!/bin/sh

sh ../tools/create-git-sha1.sh git-version.h "#define GIT_VERSION"
