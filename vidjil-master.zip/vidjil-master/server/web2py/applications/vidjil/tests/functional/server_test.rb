load 'browser_test.rb'
class ServerTest < BrowserTest

  def self.test_order
    :random
  end

end

