#!/bin/sh

python ../../../web2py.py -M -S vidjil -R applications/vidjil/tests/functional/init_test_db.py
