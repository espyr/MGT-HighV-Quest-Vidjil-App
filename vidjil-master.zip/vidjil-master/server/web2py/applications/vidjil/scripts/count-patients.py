patients = db(db.patient).count()
print patients
