
log.admin(' '.join(sys.argv[1:]))
