#!/bin/sh
python ../../../web2py.py -S vidjil -M

