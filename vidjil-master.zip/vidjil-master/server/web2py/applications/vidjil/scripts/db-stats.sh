#!/bin/sh
python ../../../web2py.py -S vidjil -M -R applications/vidjil/scripts/db-stats.py


