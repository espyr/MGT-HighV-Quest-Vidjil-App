#!/bin/sh
python ../../../web2py.py -S vidjil -M -R applications/vidjil/scripts//links.py
