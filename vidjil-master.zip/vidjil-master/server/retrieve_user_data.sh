python web2py/web2py.py -S vidjil -M -R "applications/vidjil/scripts/retrieve_user_data.py" -A "$1"

