# Vidjil – High-throughput Analysis of V(D)J Immune Repertoire

## Algorithm – Installation instructions

``` bash
make
./vidjil-algo -h
```

Detailed compilation, installation and usage instructions
can be found in [./doc/vidjil-algo.md](./doc/vidjil-algo.md).
