
VIDJIL_JSON_VERSION_REQUIRED = "2014.10"
VIDJIL_JSON_VERSION          = "2016b"

# Directory that specifies where Fuse preprocesses are stored.
# PRE_PROCESS_DIR = "/opt/fuse-pre-process"
