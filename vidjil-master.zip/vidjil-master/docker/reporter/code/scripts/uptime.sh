#!/bin/bash
uptime
