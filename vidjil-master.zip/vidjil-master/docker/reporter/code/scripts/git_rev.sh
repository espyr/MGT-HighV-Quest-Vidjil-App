#!/bin/bash
git rev-parse HEAD
