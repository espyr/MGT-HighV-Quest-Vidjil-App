#!/bin/bash
cd server/web2py/applications/vidjil/scripts
bash stats.sh
